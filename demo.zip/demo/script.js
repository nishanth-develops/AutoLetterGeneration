window.onload = () => {
    // Wait for jsPDF to be available
    const { jsPDF } = window.jspdf;
  
    window.generatePDF = function () {
      const doc = new jsPDF();
  
      const student = {
        name: "Ananya Sharma",
        rollNo: "JEE2025TS1234",
        examCenter: "Hyderabad Public School, Begumpet",
        date: "July 15, 2025",
        time: "9:00 AM - 12:00 PM"
      };
  
      doc.setFontSize(18);
      doc.text("Joint Entrance Examination - Hall Ticket", 20, 20);
  
      doc.setFontSize(12);
      doc.text(`Name: ${student.name}`, 20, 40);
      doc.text(`Roll No: ${student.rollNo}`, 20, 50);
      doc.text(`Exam Center: ${student.examCenter}`, 20, 60);
      doc.text(`Date: ${student.date}`, 20, 70);
      doc.text(`Time: ${student.time}`, 20, 80);
  
      doc.setDrawColor(0);
      doc.rect(10, 10, 190, 120);
  
      doc.save(`${student.rollNo}_HallTicket.pdf`);
    };
  };
  